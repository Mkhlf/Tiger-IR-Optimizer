package ir.datatype;

public abstract class IRType {

}

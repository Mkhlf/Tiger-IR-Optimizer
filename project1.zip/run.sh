#!/bin/bash

# Write a script to run your optimizer in this file 
# This script should take one command line argument: an path to 
# an input ir file as 
# This script should output an optimized ir file named "out.ir"

java -cp ./build middle_end.midEnd $1 > out.ir 2> err.txt

# path for 1st test case: materials/public_test_cases/quicksort/quickSort.ir
# input for 1st test case: materials/public_test_cases/quicksort/*.in
# output for 1st test case: materials/public_test_cases/quicksort/*.out


# use a counter 
# counter=0
# for input_file in materials/public_test_cases/sqrt/*.in; do
#     echo "Running optimized IR with input: $input_file"
#     # output to counter-opt.out
#     java -cp ./build IRInterpreter out.ir < $input_file > ${counter}-opt.out
#     echo "Output generated: ${input_file%.in}.out"
#     counter=$((counter+1))
# done